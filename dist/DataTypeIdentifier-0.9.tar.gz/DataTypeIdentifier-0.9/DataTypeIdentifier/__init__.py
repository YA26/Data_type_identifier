# -*- coding: utf-8 -*-

from DataTypeIdentifier.data_type_identifier import DataTypeIdentifier
